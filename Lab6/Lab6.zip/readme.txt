Saadallah,

Check: Lab6_Report_PDF_dd28977 for the PDF document submission.

Check Project_Documents for helper files including mechanical drawings, test procedure, etc.

Check Created_Part_INA188ID for the instrumentation amplifier SCH and PCB I created.

Best,
Daniel